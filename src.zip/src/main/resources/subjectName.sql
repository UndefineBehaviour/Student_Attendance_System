USE attendance_db;

INSERT IGNORE INTO subject (subject_code, subject_name) VALUES
('MCA11',  'Mathematical Foundation for Computer Science'),
('MCA12',  'Advanced Java'),
('MCA13',  'Advanced Database Management System'),
('MCA14',  'Software Project Management'),
('MCA153', 'Digital Marketing and Business Analytics'),
('MCAL11', 'Advanced Data Structures Lab'),
('MCAL12', 'Advanced Java Lab'),
('MCAL13', 'Advanced Database Management System Lab'),
('MCAL14', 'Web Technologies Lab');

SELECT subject_code, subject_name FROM subject ORDER BY subject_code;