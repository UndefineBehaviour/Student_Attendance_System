USE attendance_db;

INSERT IGNORE INTO teacher_subject (teacher_id, subject_id)
SELECT u.id, s.id
FROM (
    SELECT 'Prof.Ifrah Kampoo'      AS username, 'MCA12'  AS code
    UNION ALL SELECT 'Prof.Ifrah Kampoo',      'MCAL12'
    UNION ALL SELECT 'Prof.Suraj Kanal',       'MCA13'
    UNION ALL SELECT 'Prof.Suraj Kanal',       'MCAL13'
    UNION ALL SELECT 'Prof.Mansi Rajapurkar',  'MCA14'
    UNION ALL SELECT 'Prof.Meenakshi Paul',    'MCAL14'
    UNION ALL SELECT 'Prof.Sunita Rai',        'MCAL11'
    UNION ALL SELECT 'Prof.Neelam Harijan',    'MCA11'
    UNION ALL SELECT 'Prof.Lohita Rao',        'MCA153'
) AS m
JOIN users   u ON u.username     = m.username
JOIN subject s ON s.subject_code = m.code;

SELECT COUNT(*) AS links_saved FROM teacher_subject;

SELECT u.username, GROUP_CONCAT(s.subject_code ORDER BY s.subject_code) AS subjects
FROM teacher_subject ts
JOIN users   u ON u.id = ts.teacher_id
JOIN subject s ON s.id = ts.subject_id
GROUP BY u.username
ORDER BY u.username;