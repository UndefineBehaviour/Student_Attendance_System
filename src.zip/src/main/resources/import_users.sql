USE attendance_db;
START TRANSACTION;
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Trupt Aiya', '$2a$10$v/5kT1mEWHUHXCJHF6bYy..3urXfnCFtodW6Rb3q9On3YJmogKFKq', 'Aiya Trupt Nitesh Falguni', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA01', '1', 'FYMCA-A' FROM users WHERE username = 'Trupt Aiya';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Aatmaja Amate', '$2a$10$mXyoe/o5d7yafip4MV0/TeRKZceeCYB9hCeo5L4H7pnOsiwJl9vnS', 'Amate Aatmaja Hemant Aruna', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA02', '2', 'FYMCA-A' FROM users WHERE username = 'Aatmaja Amate';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Darshana Ambekar', '$2a$10$Tnf2nSdFtGL7HgvVibvqBOC1TZOrnuLGkHbJuwN99dfBhQ5OYFNG2', 'Ambekar Darshana Naresh Namarata', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA03', '3', 'FYMCA-A' FROM users WHERE username = 'Darshana Ambekar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Manish Andhale', '$2a$10$642fWnMuAQPXFhKActCQyu.MNJoklzgzk4TZHEVovN1/JDtU4Rd.G', 'Andhale Manish Vikas Pooja', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA04', '4', 'FYMCA-A' FROM users WHERE username = 'Manish Andhale';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Ibtesam Ansari', '$2a$10$K0CGCcZjTc3Y2EACsGo7x.q0XQR5TTw55nCOSQrm9cILyJvbE2.Xu', 'Ansari Ibtesam Abdul Majeed Abdul Majeed Sabiha Parveen', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA05', '5', 'FYMCA-A' FROM users WHERE username = 'Ibtesam Ansari';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Diya Baheti', '$2a$10$4MB96ZduaCosKu93wZhAkeIX9SYxzvjIz8H4eN6p94Od34mQcvEXG', 'Baheti Diya Prashant Padmini', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA06', '6', 'FYMCA-A' FROM users WHERE username = 'Diya Baheti';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Mayuri Banewar', '$2a$10$Q4ZmHhKFRBXfg1tiRcGZBO1APQuLNrkBDPAgR/tQ6V2/IUtw2Wy3G', 'Banewar Mayuri Bhemendra Shilpa', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA07', '7', 'FYMCA-A' FROM users WHERE username = 'Mayuri Banewar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Ruchi Barbhaya', '$2a$10$7RhWxFHwC/OAMIZ2MOhGhe1yTlDM7GdkE2nd485J.lMlX1kJdxCW6', 'Barbhaya Ruchi Nilesh Khushali', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA08', '8', 'FYMCA-A' FROM users WHERE username = 'Ruchi Barbhaya';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Simran Behera', '$2a$10$byEOilL3moMF7TmpwOWPQuFCphrF6K3z.DHKA8QEQ8iL7CsI9xXFC', 'Behera Simran Sankar Geeta', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA09', '9', 'FYMCA-A' FROM users WHERE username = 'Simran Behera';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Sujal Bhostekar', '$2a$10$BgGuiHxgenrLoC2TqJVKkuHndNXy5C8mPDOUwlHgzqUrUbiqMozIS', 'Bhostekar Sujal Mangesh Meena', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA10', '10', 'FYMCA-A' FROM users WHERE username = 'Sujal Bhostekar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Parth Borkar', '$2a$10$YuoO1DXot31ccL1GgRPGau0vnp4lPJzBMGs1oNTWrliek5UrXT1Ce', 'Borkar Parth Suhas Sakshi', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA11', '11', 'FYMCA-A' FROM users WHERE username = 'Parth Borkar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Janhavi Botke', '$2a$10$qiO4sdwg49MfKGBsgvFMbOgUjJVyCryG25lloVduoaxBTsye4.16S', 'Botke Janhavi Sudhakar Suvarna', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA12', '12', 'FYMCA-A' FROM users WHERE username = 'Janhavi Botke';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Nishit Chalke', '$2a$10$FsKq70gKE0NygfDU1Hqi9OdN9npcorelAHSSjLy1LmSNETRN3To6O', 'Chalke Nishit Sunil Nidhi', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA13', '13', 'FYMCA-A' FROM users WHERE username = 'Nishit Chalke';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Aayush Chaudhari', '$2a$10$p71DXZ/bt8pTKp/D7q548.xkBWJIhSgWj/VXlSoslbaaL7ql9w7Ri', 'Chaudhari Aayush Surendraprasad Aarti', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA14', '14', 'FYMCA-A' FROM users WHERE username = 'Aayush Chaudhari';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Himanshu Chaudhary', '$2a$10$cnWrGPqTmIqbS9CBMSs4QuPC4VNAggLWJ9AqZ0C27CDQq/qBz7.r.', 'Chaudhary Himanshu Pawan Rekha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA15', '15', 'FYMCA-A' FROM users WHERE username = 'Himanshu Chaudhary';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Aarti Chavan', '$2a$10$0WZfEpfp4FELpu1nVxtHr.v7tjJsIbVSkadOhhYHdk247QQPhhCyi', 'Chavan Aarti Pradeep Jyoti', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA16', '16', 'FYMCA-A' FROM users WHERE username = 'Aarti Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Kalpesh Chavan', '$2a$10$jI50ZuGwA/cylbqvA3ukVeWxfo2IN1uG.kpPDlM.DPZEYLqhdYvcW', 'Chavan Kalpesh Avinash Akshaya', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA17', '17', 'FYMCA-A' FROM users WHERE username = 'Kalpesh Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Madhura Chavan', '$2a$10$Fo04P7i72hC.h.0p0Fei3eJuHXv2Z81fhZefz6Vuq7ZPL9iZGkIg6', 'Chavan Madhura Kashiram Kanchan', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA18', '18', 'FYMCA-A' FROM users WHERE username = 'Madhura Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Mishthi Chavan', '$2a$10$vHTBwKnoaSjbaJy/s94wrOGRpQXXRiRXTQcDTUb1EvKz/4iKkmnI6', 'Chavan Mishthi Nilesh Jyoti', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA19', '19', 'FYMCA-A' FROM users WHERE username = 'Mishthi Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Srushti Chavan', '$2a$10$Y7ZpDZ/zXp4BAAlpty09H.eYshMJ6/iaWcLJLRAzT7fm9LPz8RFky', 'Chavan Srushti Sakharam Samiksha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA20', '20', 'FYMCA-A' FROM users WHERE username = 'Srushti Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Vinayak Chavan', '$2a$10$TzwrfL.xRhWZiIgQLgOhoOVzlIjUCc8vzTV/I6sCFEfkjSx9Cn...', 'Chavan Vinayak Maruti Sunita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA21', '21', 'FYMCA-A' FROM users WHERE username = 'Vinayak Chavan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Atharv Chawan', '$2a$10$EnDkxlIlpziZnYwlB86Z2OycM1Y.xUy4Y5mgGBWHDci2yWuXAfqYe', 'Chawan Atharv Sunil Shweta', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA22', '22', 'FYMCA-A' FROM users WHERE username = 'Atharv Chawan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Omsai Chukkapuram', '$2a$10$HdvdnLk5aoFV7PIau6wCP.mwmhu2fAuncT.ZEz/UppDKrSjhj1Qsa', 'Chukkapuram Omsai Raju Uma', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA23', '23', 'FYMCA-A' FROM users WHERE username = 'Omsai Chukkapuram';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Pauravi Desai', '$2a$10$lFMnQqY9XGD5m11JcW6Fs.IHrOHulynKUMVfLiFB5OgZsnUoxsycO', 'Desai Pauravi Milind Mrudula', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA24', '24', 'FYMCA-A' FROM users WHERE username = 'Pauravi Desai';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Shraddha Desai', '$2a$10$RLZ6ibMddfrQAhuZgMXqOO8XfmxBizE0YVR1JApvM0v0637y5xgIS', 'Desai Shraddha Shridhar Sayali', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA25', '25', 'FYMCA-A' FROM users WHERE username = 'Shraddha Desai';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Harshada Deshmukh', '$2a$10$sEkU3jDw3r3Q.S7mkhCgRuF6.YFQsh.zHi.GL6PG42PJ0wvlSCiDa', 'Deshmukh Harshada Maruti Mangal', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA26', '26', 'FYMCA-A' FROM users WHERE username = 'Harshada Deshmukh';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Sakshi Dhanve', '$2a$10$mr1ANbPJDs.K/0GGUjmNSucYx63KAV2MDdSvT.phB0TtaX2qbExOe', 'Dhanve Sakshi Sanjay Archana', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA27', '27', 'FYMCA-A' FROM users WHERE username = 'Sakshi Dhanve';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Bhavisha Dhopte', '$2a$10$84ifGAOkuSSkrkshby4eR.lOsI/NBvmzWHJZhbDcQ3WkQ.Voiz5aS', 'Dhopte Bhavisha Sandeep Pratibha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA28', '28', 'FYMCA-A' FROM users WHERE username = 'Bhavisha Dhopte';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Nikhil Gaikar', '$2a$10$IH3Ah3I/SRBV9LzLFWdX0eo6mxM4XuiQZEmrbYbYv2gU7/Ez6pa/q', 'Gaikar Nikhil Sanjay Smita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA29', '29', 'FYMCA-A' FROM users WHERE username = 'Nikhil Gaikar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Dhanahsree Gaikwad', '$2a$10$BENIJjZ/adSmEG4NUi7U6e9c2G/m/tTMtg9aiznng8jxgulpBw7cK', 'Gaikwad Dhanahsree Sandeep Madhuri', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA30', '30', 'FYMCA-A' FROM users WHERE username = 'Dhanahsree Gaikwad';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Pratik Gaikwad', '$2a$10$MuMBDPPPjQvgJTq5Z.h00OymbYWrfCbcQGDvIbfDDSUqPKaQBQIDy', 'Gaikwad Pratik Dnyaneshwar Smita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA31', '31', 'FYMCA-A' FROM users WHERE username = 'Pratik Gaikwad';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Krish Gohel', '$2a$10$zy8TmTWDgaj.tcrhQFI8Y.zdkACBqC1rbKY4idyc2iz4L3Yu8z45O', 'Gohel Krish Vijay Amisha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA32', '32', 'FYMCA-A' FROM users WHERE username = 'Krish Gohel';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Ashwini Guggilla', '$2a$10$FM/EjFTxFUJY9HNTyT1iA.mmq70HmeQSKP/AAvbRdGHb8xKPsEJKu', 'Guggilla Ashwini Saibabu Ellavva', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA33', '33', 'FYMCA-A' FROM users WHERE username = 'Ashwini Guggilla';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Shivam Gupta', '$2a$10$KuYnj9DcdlJ2stuCgNwJBumyy2USSnhbdgPklahUrXz7QqiOoCFj6', 'Gupta Shivam Manoj Reeta', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA34', '34', 'FYMCA-A' FROM users WHERE username = 'Shivam Gupta';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Veena Guram', '$2a$10$lZ56ZYdVyhbYQs9stJ7mKOF4DnWArRMiu1W/Er2T/DH8C4jFlmapW', 'Guram Veena Devdas Ambika', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA35', '35', 'FYMCA-A' FROM users WHERE username = 'Veena Guram';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Sameera Gurav', '$2a$10$s6pN2236h16Ttdi3IcwcBulab7glSSE0bsXXmiVAr99T2DVqY5K5a', 'Gurav Sameera Laxman Veena', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA36', '36', 'FYMCA-A' FROM users WHERE username = 'Sameera Gurav';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Soham Halde', '$2a$10$sWg7lniYC3Pg2a0BD1d7muFwohjoawSXV7C2QWPtb6EmlL114qWe.', 'Halde Soham Sandeep Sandhya', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA37', '37', 'FYMCA-A' FROM users WHERE username = 'Soham Halde';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Ahmed Idrisi', '$2a$10$/.pU4RAcTqczBp0X.qIEOO0o8o2JeC9F4LXtGLp0G4sptZDDirucK', 'Idrisi Mohammad Ahmed Mohammad Ayub Jahida Banu', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA38', '38', 'FYMCA-A' FROM users WHERE username = 'Ahmed Idrisi';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Bhakti Indulkar', '$2a$10$MXQC4oNjfoX/BEgf58mRc.RMnGZz37nhxm1ZRWJLfz/TwyPf2mN.a', 'Indulkar Bhakti Janardan Jyoti', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA39', '39', 'FYMCA-A' FROM users WHERE username = 'Bhakti Indulkar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Ayush Jadhav', '$2a$10$2NB3fndhAN4JhCrx34dbWugFgy71Fwk1N4ptCfChsZMoNP7KUVbNa', 'Jadhav Ayush Yogesh Vandana', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA40', '40', 'FYMCA-A' FROM users WHERE username = 'Ayush Jadhav';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Tanmay Jadhav', '$2a$10$0xns6pTV47qugGDowTzhN..VeUclwvW99qLHuiVpS5M4aGujF1Syq', 'Jadhav Tanmay Jayesh Jyoti', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA41', '41', 'FYMCA-A' FROM users WHERE username = 'Tanmay Jadhav';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Chandrakant Jaiswar', '$2a$10$ni1FAFI5UYcnFqgyNeMXue93fK7cv.JT8Xu53yKhnBTieqXpZCD16', 'Jaiswar Chandrakant Ramashankar Mamta', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA42', '42', 'FYMCA-A' FROM users WHERE username = 'Chandrakant Jaiswar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Khushi Jena', '$2a$10$n3EBtWTT4qxy9gsMjZ/OzOFyLQEXcnl911O6iO74djGMx5M7QFswm', 'Jena Khushi Ramchandra Kunni', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA43', '43', 'FYMCA-A' FROM users WHERE username = 'Khushi Jena';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Swayam Kaduskar', '$2a$10$Xj42vmi/XfcUuTL7HdcrPufHO4SVLRgEfCnxGTt73.62r0JLqt9T2', 'Kaduskar Swayam Raju Suvarna', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA44', '44', 'FYMCA-A' FROM users WHERE username = 'Swayam Kaduskar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Roshan Kahar', '$2a$10$zPx1sS32dKoXnlfdQCAhGe7k1IeA1Um1/O0v/nkM62jTFsxh.it6u', 'Kahar Roshan Ajay Gyanmati', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA45', '45', 'FYMCA-A' FROM users WHERE username = 'Roshan Kahar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Jai Kantharia', '$2a$10$X8d3lTMLec0nT0lfhkS38eOgyGyIDkt411ostYpgrwTPMbDuKBqsy', 'Kantharia Jai Arun Surekha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA46', '46', 'FYMCA-A' FROM users WHERE username = 'Jai Kantharia';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Om Kapri', '$2a$10$aADnqwkpTt.SzS6wS42PXuM0Z60gZ2GqSM9WxYwmp8P0OIbE9b4Fy', 'Kapri Om Yogesh Poonam', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA47', '47', 'FYMCA-A' FROM users WHERE username = 'Om Kapri';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Adib Khan', '$2a$10$AtdtKsQlkg.owH31OxR92unZtP2RkwFrZewSjMlp5rcjlSC1Uv8MC', 'Khan Adib Akhtar Hussain Mariyam Banu', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA48', '48', 'FYMCA-A' FROM users WHERE username = 'Adib Khan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Azmeer Khan', '$2a$10$ZYTnZYQXoDf08YGpJ9W0n.sYIZTJ6WtcDU0RAXlF/cfgzKOmhuN..', 'Khan Azmeer Nazar Mohammad Umme Habiba', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA49', '49', 'FYMCA-A' FROM users WHERE username = 'Azmeer Khan';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prachi Kharage', '$2a$10$rGlBUos4G2v4MegkP7Pr8eQNq97qyqK5DUqElIDhd3Z7aa4ciORRO', 'Kharage Prachi Ravindra Nita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA50', '50', 'FYMCA-A' FROM users WHERE username = 'Prachi Kharage';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Pratik Kharat', '$2a$10$P6dt7iiialK1x1Ljd3RKjOQcfCigFV1jZ88j/X.5l6YQIA9.Vjndi', 'Kharat Pratik Sanjay Savita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA51', '51', 'FYMCA-A' FROM users WHERE username = 'Pratik Kharat';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Atharva Khot', '$2a$10$TRZh.PMboTulPuPL3c64Ve/gmQGTa01NtH9wLQ3pO8xmvRMU5Pd4O', 'Khot Atharva Namdev Pratibha', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA52', '52', 'FYMCA-A' FROM users WHERE username = 'Atharva Khot';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Bhavesh Korde', '$2a$10$6glPvL8WrhvawkPBJnWEpu9kKhmvR5faWfaQkpAOaIsU0x2jRJFDC', 'Korde Bhavesh Ramdas Chhaya', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA53', '53', 'FYMCA-A' FROM users WHERE username = 'Bhavesh Korde';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Manish Kosti', '$2a$10$795pAcogJn2Kxho/rPcrV.q.ET6GFafgwCXQs6luVQNNsGxloMQIC', 'Kosti Manish Magan Meena', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA54', '54', 'FYMCA-A' FROM users WHERE username = 'Manish Kosti';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Neha Kumbhar', '$2a$10$KY9Ncb5DmSycjLooihwM5.bP9Cs2Ani01sAKj56M.08xwxvqCvqY6', 'Kumbhar Neha Kiran Sunita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA55', '55', 'FYMCA-A' FROM users WHERE username = 'Neha Kumbhar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Mangesh Mandal', '$2a$10$CqZzCGBNoUK9MaE8NefbveDbEKFGnezqS1ZgzWHnWtx8/FAQSqfjy', 'Mandal Mangesh Ashok Annu', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA56', '56', 'FYMCA-A' FROM users WHERE username = 'Mangesh Mandal';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Nikhil Mande', '$2a$10$og/aD86t0VCkmVKGqd5p3e/haWngGMMbm.kThkuErKRC0ZlKcdbry', 'Mande Nikhil Umesh Savita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA57', '57', 'FYMCA-A' FROM users WHERE username = 'Nikhil Mande';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Sangeeta Maurya', '$2a$10$Y8lKCEYoEMqjXqLvRPzAy.3YbuLnl67MrTFL6lqaxuR41Gf0VzSqC', 'Maurya Sangeeta Shambhunath Manavati', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA58', '58', 'FYMCA-A' FROM users WHERE username = 'Sangeeta Maurya';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Nayan Mehta', '$2a$10$BUNysjwqv24rEgxEiKrBUu20tGAwYzwBlLU2Kq08z/mc/wMHL8mYy', 'Mehta Nayan Hemraj Mehta Geeta Mehta', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA59', '59', 'FYMCA-A' FROM users WHERE username = 'Nayan Mehta';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Saurav Mirajkar', '$2a$10$F.256JSEaiQRj95jznp4N.Y2m7WnqAqg6n3J83.As1wCcPQH1iS7q', 'Mirajkar Saurav Mangesh Sarita', 'STUDENT');
INSERT INTO student (user_id, student_code, roll_no, class_name) SELECT id, '26MCA60', '60', 'FYMCA-A' FROM users WHERE username = 'Saurav Mirajkar';

INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Ifrah Kampoo', '$2a$10$VarAEORrHt0tQ6gpvgVvHOCWZuLir5K5U/CM1lli/p.JeHraYQxIK', 'Ifrah Rizwan Kampoo', 'COORDINATOR');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Suraj Kanal', '$2a$10$lV2lHrO2Us0jW5NUXiapQupWSxaZisleLVPtCYkJR6PO3Sqm/MKCe', 'Suraj Kamal Kanal', 'TEACHER');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Mansi Rajapurkar', '$2a$10$8W3jEoPQ/yTB54dcbPztk./Dh9/mvXQO1G0vb9NpP2mv7RDgvHlAO', 'Mansi M Rajapurkar', 'TEACHER');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Meenakshi Paul', '$2a$10$e3dku5HypBjUPhfMp754weIRX7/as3O1IdlRMgcgcsIcWCD/zKdMm', 'Meenakshi Paul', 'TEACHER');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Sunita Rai', '$2a$10$lLjtQsnQFzjAZdZGdjJB2erk4AIiV/A3zX3ZLBtk7KT9JiBw8.hFm', 'Sunita Rai', 'TEACHER');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Neelam Harijan', '$2a$10$yIqX1/pdYWI2KHzX1tx9a.PVeB2JWpFKNel4UWXW3t90DEy6bx4Ny', 'Neelam', 'TEACHER');
INSERT INTO users (username, password_hash, full_name, role) VALUES ('Prof.Lohita Rao', '$2a$10$EwSi3l5P19jpZ4ZVF276eeQ0sN6x.MBa9SgcewrapPCffBALju98q', 'Lohita Rao', 'TEACHER');
COMMIT;
